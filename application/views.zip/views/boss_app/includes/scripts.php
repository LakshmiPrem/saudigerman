<?php $spath =   base_url('assets/boss/'); ?>
<script src="<?php echo $spath .'js/jquery-3.2.1.slim.min.js';?>"></script>
<script src="<?php echo $spath .'js/bootstrap.min.js';?>"></script>
<script  src="<?php echo $spath .'js/jquery.easeScroll.js';?>"></script>
<script type="text/javascript" src="<?php echo $spath .'script.js';?>"></script>
<!-- <script type="text/javascript">
   $("#addednavbar").load("./navbar.html");
</script> -->