<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
	<div class="content">
		<div class="panel_s">
			<div class="panel-body">
            <p style="font-size: 20px;"><?php echo $title; ?></p>

                <a href="#" onclick="new_ocr();" class="btn btn-info pull-left display-block"><?php echo _l('new_ocr'); ?></a>
						
			</div>
		</div>
	</div>
</div>
<?php init_tail(); ?>
</body>
</html>
